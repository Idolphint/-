import pandas as pd
import pickle
import numpy as np
class Company(object):
    def __init__(self, data):

        id, open_date, ratal_class, code_regi, hy_dm, hyzl_dm, hydl_dm, hyml_dm = data
        open_day = open_date.split(' ')[0]
        open_day = open_day.split('-')
        open_date = [int(open_day[0]), int(open_day[1]), int(open_day[2])]
        hy_dm = str(hy_dm)
        # print(ratal_class)
        self.id = id
        self.enterprise_opening_date = open_date
        # self.code_enterprise_ratal_classes = ratal_class
        # self.code_enterprise_registration = code_regi
        self.HY_DM = [ratal_class, code_regi, hy_dm[-1], hy_dm[-2],hy_dm[-3:], hyml_dm]  # 行业代码、中类、大类、门类
        self.tax_return = []
        self.tax_pay = []
        self.investor_info = []
        self.label = -1

    def get_four_investor(self):
        sort_inv = sorted(self.investor_info, key=lambda x: x[2])
        out_inv = np.zeros((4,2))
        for i in range(min(len(sort_inv), 4)):
            out_inv[i,0] = sort_inv[i][2]
            out_inv[i,1] = sort_inv[i][3]
        return out_inv

    def add_tax_return(self, data):
        id, tax_return_date, return_ddl, code_account, code_item, tax_begin, tax_end, sales = data
        return_day = tax_return_date.split("-")
        ddl = return_ddl.split("-")
        tax_begin_day = tax_begin.split('-')
        tax_return_date = [int(i) for i in return_day]
        return_ddl = [int(i) for i in ddl]
        tax_begin = [int(i) for i in tax_begin_day]
        code_account = str(code_account)
        code_item = str(code_item)

        assert code_account+code_item[len(code_account):] == code_item
        code_item = code_item[len(code_account):]
        sales = float(sales)
        # 相对于公司成立日期的月数
        until_ddl = (return_ddl[1] - tax_return_date[1])*30 + return_ddl[2] - tax_return_date[2]
        rela_tax_begin = (tax_begin[0]-self.enterprise_opening_date[0])*12 +\
                         tax_begin[1]-self.enterprise_opening_date[1]
        if len(self.tax_return) <= rela_tax_begin:
            self.tax_return += [None]*(rela_tax_begin-len(self.tax_return)+1)

        self.tax_return[rela_tax_begin] = {code_item:[sales, until_ddl, code_account]}

    def add_tax_payment(self, data):
        id, ddl, pay_date, pay_begin, pay_end, code_account, code_item, tax_class, ratal = data
        ddl_day = ddl.split("-")
        pay_day = pay_date.split("-")
        pay_begin_day = pay_begin.split("-")
        ddl = [int(i) for i in ddl_day]
        pay_date = [int(i) for i in pay_day]
        pay_begin = [int(i) for i in pay_begin_day]
        code_item = str(code_item)
        tax_class = str(tax_class)
        until_ddl = (ddl[1]-pay_date[1])*30+(ddl[2]-pay_date[2])
        rela_tax_begin = (pay_begin[0]-self.enterprise_opening_date[0])*12 +\
                         pay_begin[1]-self.enterprise_opening_date[1]
        if len(self.tax_pay) <= rela_tax_begin:
            self.tax_pay += [None]*(rela_tax_begin-len(self.tax_pay)+1)
        self.tax_pay[rela_tax_begin] = {code_item:[ratal, until_ddl, tax_class, code_account]}

    def add_investor_info(self, data):
        id, investor_id, invest_class, invest_rate, invest_amount = data
        self.investor_info.append([investor_id, invest_class, invest_rate, invest_amount])

    def add_label(self, data):
        self.label = int(data['label'])

def init_dataset(mode = "train", eval_rate=0.1):
    dataset = {}
    base_info = pd.read_csv("../data_jk/%s_basic_info.csv"%mode, encoding='utf-8')
    tax_return = pd.read_csv("../data_jk/%s_tax_return_.csv"%mode, encoding='utf-8')
    tax_payment = pd.read_csv("../data_jk/%s_tax_payment_.csv" % mode, encoding='utf-8')
    tax_invest = pd.read_csv("../data_jk/%s_investor_info.csv" % mode, encoding='utf-8')
    base_info.fillna({'code_enterprise_ratal_classes':'0', 'HYML_DM':'A'}, inplace=True)
    for index, row in base_info.iterrows():
        id = row['ID']
        dataset[id] = Company(row)
    for index, row in tax_return.iterrows():
        id = row['ID']
        comp = dataset[id]
        comp.add_tax_return(row)
        dataset[id] = comp
    for index, row in tax_payment.iterrows():
        id = row['ID']
        comp = dataset[id]
        comp.add_tax_payment(row)
        dataset[id] = comp
    for index, row in tax_invest.iterrows():
        id = row['ID']
        comp = dataset[id]
        comp.add_investor_info(row)
        dataset[id] = comp
    if mode == 'train':
        label = pd.read_csv("../data_jk/%s_label.csv" % mode, encoding='utf-8')
        for index, row in label.iterrows():
            id = row['SHXYDM']
            comp = dataset[id]
            comp.add_label(row)
            dataset[id] = comp
        eval_dataset = list(dataset.keys())[int(len(dataset.keys())*eval_rate):]
        eval_out = {ev: dataset[ev] for ev in eval_dataset}
        [dataset.pop(ev) for ev in eval_dataset]
        pickle.dump(dataset, open("../data_jk/train_data.pkl", 'wb'))
        pickle.dump(eval_out, open("../data_jk/eval_data.pkl", 'wb'))
    else:
        pickle.dump(dataset, open("../data_jk/%s.pkl"%mode, 'wb'))

    return dataset


if __name__ == '__main__':
    init_dataset(mode='train')