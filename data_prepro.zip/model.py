import torch
import torch.nn as nn
class Embeding_classify(nn.Module):
    def __init__(self):
        super(Embeding_classify, self).__init__()
        self.emd_hy_layer = nn.Embedding(500, 10)
        self.emb_inv_fc = nn.Linear(8, 2)
        self.emb_tax = ?