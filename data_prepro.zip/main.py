from data import Company
import pickle

train_f = open("../data_jk/train_data.pkl", 'rb')
eval_f = open("../data_jk/eval_data.pkl", 'rb')
test_f = open("../data_jk/test.pkl", 'rb')
train_data = pickle.load(train_f)
# eval_data = pickle.load(eval_f)
# test_data = pickle.load(test_f)

inv_n = []
for id, comp in train_data.items():
    all_money = -1
    all_rate = 0
    inv_n.append(len(comp.investor_info))
    # for inv in comp.investor_info:
    #     if all_money != -1 and abs(all_money - (inv[3] / inv[2])) > 1:
    #         print("different ", all_money-(inv[3] / inv[2]) )
    #     all_money = inv[3] / inv[2]
    #     all_rate += inv[2]
    # if all_rate != 1:
    #     print(all_rate)
print(sum(inv_n)/len(inv_n), min(inv_n), max(inv_n), inv_n[int(len(inv_n) // 2)])